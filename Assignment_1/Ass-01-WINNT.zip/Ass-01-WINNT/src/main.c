//     $Date: 2018-03-11 05:18:25 +1100 (Sun, 11 Mar 2018) $
// $Revision: 1206 $
//   $Author: Peter $

// Assignment 1 WINNT main entry point

#include "Ass-01.h"

int main(void)
{
	return Ass_01_Main();
}
