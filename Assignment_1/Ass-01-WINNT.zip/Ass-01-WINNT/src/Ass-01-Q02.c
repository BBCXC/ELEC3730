//     $Date: 2018-03-11 05:18:25 +1100 (Sun, 11 Mar 2018) $
// $Revision: 1206 $
//   $Author: Peter $

// Question 2

#include "Ass-01.h"

int read_pcm_wavefile(pcm_wavefile_header_t *header_p, char **data_p, char *filename)
{
	  //
	  // WRITE CODE HERE
	  //
	  printf("CODE TO BE WRITTEN QUESTION 2...\n\n");
	  printf("I got here 7");
	  return 1;
}

int write_pcm_wavefile(pcm_wavefile_header_t *header_p, char *data, char *filename)
{
  //
  // WRITE CODE
  //
  printf("CODE TO BE WRITTEN QUESTION 2...\n\n");
  printf("I got here 6");
  return 1;
}
